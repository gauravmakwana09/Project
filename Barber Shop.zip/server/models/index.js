const { sequelize } = require('../config/db');
const { DataTypes } = require('sequelize');

// Import models
const User = require('./User');
const Service = require('./Service');
const Appointment = require('./Appointment');
const Schedule = require('./Schedule');

// Define Associations
User.hasMany(Appointment, { foreignKey: 'userId', as: 'appointments' });
User.hasMany(Appointment, { foreignKey: 'barberId', as: 'barberAppointments' });
User.hasMany(Schedule, { foreignKey: 'barberId', as: 'schedules' });

Appointment.belongsTo(User, { foreignKey: 'userId', as: 'user' });
Appointment.belongsTo(User, { foreignKey: 'barberId', as: 'barber' });
Appointment.belongsTo(Service, { foreignKey: 'serviceId', as: 'service' });

Service.hasMany(Appointment, { foreignKey: 'serviceId', as: 'appointments' });

Schedule.belongsTo(User, { foreignKey: 'barberId', as: 'barber' });

module.exports = {
    sequelize,
    User,
    Service,
    Appointment,
    Schedule,
};
