const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');

const Schedule = sequelize.define('Schedule', {
    dayOfWeek: {
        type: DataTypes.INTEGER,
        allowNull: false, // 0-6
    },
    startTime: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    endTime: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    isAvailable: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
    },
    barberId: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
});

module.exports = Schedule;
