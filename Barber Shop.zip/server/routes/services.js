const express = require('express');
const router = express.Router();
const { Service } = require('../models');
const { protect, authorize } = require('../middleware/authMiddleware');

// @desc    Get all services
// @route   GET /api/services
// @access  Public
router.get('/', async (req, res) => {
    try {
        const services = await Service.findAll();
        res.json(services);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// @desc    Get single service
// @route   GET /api/services/:id
// @access  Public
router.get('/:id', async (req, res) => {
    try {
        const service = await Service.findByPk(req.params.id);
        if (service) {
            res.json(service);
        } else {
            res.status(404).json({ message: 'Service not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// @desc    Create a service
// @route   POST /api/services
// @access  Private/Admin
router.post('/', protect, authorize('admin'), async (req, res) => {
    const { name, description, price, duration, image } = req.body;

    try {
        const service = await Service.create({
            name,
            description,
            price,
            duration,
            image,
        });
        res.status(201).json(service);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// @desc    Update a service
// @route   PUT /api/services/:id
// @access  Private/Admin
router.put('/:id', protect, authorize('admin'), async (req, res) => {
    const { name, description, price, duration, image } = req.body;

    try {
        const service = await Service.findByPk(req.params.id);

        if (service) {
            service.name = name || service.name;
            service.description = description || service.description;
            service.price = price || service.price;
            service.duration = duration || service.duration;
            service.image = image || service.image;

            const updatedService = await service.save();
            res.json(updatedService);
        } else {
            res.status(404).json({ message: 'Service not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// @desc    Delete a service
// @route   DELETE /api/services/:id
// @access  Private/Admin
router.delete('/:id', protect, authorize('admin'), async (req, res) => {
    try {
        const service = await Service.findByPk(req.params.id);

        if (service) {
            await service.destroy();
            res.json({ message: 'Service removed' });
        } else {
            res.status(404).json({ message: 'Service not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
