const express = require('express');
const router = express.Router();
const { Appointment, Service, User } = require('../models');
const { protect, authorize } = require('../middleware/authMiddleware');

// @desc    Create new appointment
// @route   POST /api/appointments
// @access  Private
router.post('/', protect, async (req, res) => {
    const { serviceId, barberId, date } = req.body;
    console.log('Booking Appointment:', { userId: req.user.id, serviceId, barberId, date });

    try {
        const appointment = await Appointment.create({
            userId: req.user.id,
            serviceId,
            barberId,
            date,
        });

        res.status(201).json(appointment);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// @desc    Get logged in user appointments
// @route   GET /api/appointments/my
// @access  Private
router.get('/my', protect, async (req, res) => {
    try {
        const appointments = await Appointment.findAll({
            where: { userId: req.user.id },
            include: [
                { model: Service, as: 'service' },
                { model: User, as: 'barber', attributes: ['name', 'email'] }
            ]
        });
        res.json(appointments);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// @desc    Get barber appointments
// @route   GET /api/appointments/barber
// @access  Private/Barber/Admin
router.get('/barber', protect, authorize('barber', 'admin'), async (req, res) => {
    try {
        const appointments = await Appointment.findAll({
            where: { barberId: req.user.id },
            include: [
                { model: Service, as: 'service' },
                { model: User, as: 'user', attributes: ['name', 'email'] }
            ]
        });
        res.json(appointments);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// @desc    Update appointment status
// @route   PUT /api/appointments/:id
// @access  Private/Barber/Admin
router.put('/:id', protect, authorize('barber', 'admin'), async (req, res) => {
    const { status } = req.body;

    try {
        const appointment = await Appointment.findByPk(req.params.id);

        if (appointment) {
            // Check if barber owns this appointment or is admin
            if (req.user.role !== 'admin' && appointment.barberId !== req.user.id) {
                return res.status(401).json({ message: 'Not authorized' });
            }

            appointment.status = status;
            const updatedAppointment = await appointment.save();
            res.json(updatedAppointment);
        } else {
            res.status(404).json({ message: 'Appointment not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
