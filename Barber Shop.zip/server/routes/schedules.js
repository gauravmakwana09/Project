const express = require('express');
const router = express.Router();
const { Schedule } = require('../models');
const { protect, authorize } = require('../middleware/authMiddleware');

// @desc    Set/Update schedule
// @route   POST /api/schedules
// @access  Private/Barber/Admin
router.post('/', protect, authorize('barber', 'admin'), async (req, res) => {
    const { dayOfWeek, startTime, endTime, isAvailable } = req.body;

    try {
        // Check if schedule exists for this day
        let schedule = await Schedule.findOne({
            where: {
                barberId: req.user.id,
                dayOfWeek
            }
        });

        if (schedule) {
            schedule.startTime = startTime;
            schedule.endTime = endTime;
            schedule.isAvailable = isAvailable;
            await schedule.save();
            res.json(schedule);
        } else {
            schedule = await Schedule.create({
                barberId: req.user.id,
                dayOfWeek,
                startTime,
                endTime,
                isAvailable
            });
            res.status(201).json(schedule);
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// @desc    Get barber schedule
// @route   GET /api/schedules/:barberId
// @access  Public
router.get('/:barberId', async (req, res) => {
    try {
        const schedules = await Schedule.findAll({
            where: { barberId: req.params.barberId }
        });
        res.json(schedules);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
