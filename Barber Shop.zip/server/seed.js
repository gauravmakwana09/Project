const { sequelize, User, Service, Appointment, Schedule } = require('./models');
const dotenv = require('dotenv');

dotenv.config();

const users = [
    {
        name: 'Admin User',
        email: 'admin@example.com',
        password: 'password123',
        role: 'admin',
    },
    {
        name: 'Barber User',
        email: 'barber@example.com',
        password: 'password123',
        role: 'barber',
    },
    {
        name: 'Normal User',
        email: 'user@example.com',
        password: 'password123',
        role: 'user',
    },
];

const services = [
    {
        name: 'Haircut',
        description: 'Standard haircut',
        price: 30,
        duration: 30,
    },
    {
        name: 'Shave',
        description: 'Hot towel shave',
        price: 20,
        duration: 20,
    },
];

const seedDB = async () => {
    try {
        await sequelize.authenticate();
        console.log('MySQL Connected');

        // Sync database and force clear
        await sequelize.sync({ force: true });
        console.log('Database Synced & Cleared');

        // Create Users
        for (const user of users) {
            await User.create(user);
        }

        // Create Services
        await Service.bulkCreate(services);

        console.log('Data Imported!');
        process.exit();
    } catch (error) {
        console.error(`${error}`);
        process.exit(1);
    }
};

seedDB();
