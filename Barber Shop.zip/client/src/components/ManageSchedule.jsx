import { useState, useEffect } from 'react';
import api from '../api/axios';

const ManageSchedule = () => {
    const [schedules, setSchedules] = useState([]);
    const [dayOfWeek, setDayOfWeek] = useState(1); // Monday
    const [startTime, setStartTime] = useState('09:00');
    const [endTime, setEndTime] = useState('17:00');

    useEffect(() => {
        fetchSchedule();
    }, []);

    const fetchSchedule = async () => {
        try {
            // Assuming we have an endpoint to get my schedule or by ID
            // For now, let's just use the create/update endpoint to set it
            // To get it, we need the user ID. 
            // Let's just implement the setting part for now.
        } catch (error) {
            console.error(error);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await api.post('/schedules', { dayOfWeek, startTime, endTime, isAvailable: true });
            alert('Schedule updated!');
        } catch (error) {
            console.error(error);
            alert('Failed to update schedule');
        }
    };

    return (
        <div style={{ marginTop: '20px' }}>
            <h3>Update Schedule</h3>
            <form onSubmit={handleSubmit} style={{ display: 'grid', gap: '10px', maxWidth: '400px' }}>
                <select value={dayOfWeek} onChange={e => setDayOfWeek(Number(e.target.value))}>
                    <option value={0}>Sunday</option>
                    <option value={1}>Monday</option>
                    <option value={2}>Tuesday</option>
                    <option value={3}>Wednesday</option>
                    <option value={4}>Thursday</option>
                    <option value={5}>Friday</option>
                    <option value={6}>Saturday</option>
                </select>
                <div style={{ display: 'flex', gap: '10px' }}>
                    <input type="time" value={startTime} onChange={e => setStartTime(e.target.value)} required />
                    <span>to</span>
                    <input type="time" value={endTime} onChange={e => setEndTime(e.target.value)} required />
                </div>
                <button type="submit" className="btn btn-primary">Set Availability</button>
            </form>
        </div>
    );
};

export default ManageSchedule;
