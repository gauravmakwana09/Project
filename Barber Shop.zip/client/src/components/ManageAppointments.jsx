import { useState, useEffect } from 'react';
import api from '../api/axios';

const ManageAppointments = () => {
    const [appointments, setAppointments] = useState([]);
    const [message, setMessage] = useState('');

    useEffect(() => {
        fetchAppointments();
    }, []);

    const fetchAppointments = async () => {
        try {
            // Admin sees all appointments via this endpoint as per backend logic
            const res = await api.get('/appointments/barber');
            setAppointments(res.data);
        } catch (error) {
            console.error(error);
            setMessage('Failed to fetch appointments');
        }
    };

    return (
        <div>
            <h3>All Appointments</h3>
            {message && <p className="alert">{message}</p>}
            {appointments.length === 0 ? (
                <p>No appointments found.</p>
            ) : (
                <table className="table">
                    <thead>
                        <tr>
                            <th>Service</th>
                            <th>Date</th>
                            <th>Client</th>
                            <th>Barber</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {appointments.map(appt => (
                            <tr key={appt._id}>
                                <td>{appt.service?.name}</td>
                                <td>{new Date(appt.date).toLocaleString()}</td>
                                <td>{appt.user?.name}</td>
                                <td>{appt.barber?.name}</td>
                                <td>{appt.status}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
};

export default ManageAppointments;
