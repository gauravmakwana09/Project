import { useState } from 'react';
import api from '../api/axios';

const ManageServices = ({ services, onServiceAdded }) => {
    const [name, setName] = useState('');
    const [price, setPrice] = useState('');
    const [duration, setDuration] = useState('');
    const [description, setDescription] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const res = await api.post('/services', { name, price, duration, description });
            onServiceAdded(res.data);
            setName('');
            setPrice('');
            setDuration('');
            setDescription('');
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <div style={{ marginTop: '20px' }}>
            <h3>Add New Service</h3>
            <form onSubmit={handleSubmit} style={{ display: 'grid', gap: '10px', maxWidth: '400px' }}>
                <input placeholder="Name" value={name} onChange={e => setName(e.target.value)} required />
                <input placeholder="Price" type="number" value={price} onChange={e => setPrice(e.target.value)} required />
                <input placeholder="Duration (min)" type="number" value={duration} onChange={e => setDuration(e.target.value)} required />
                <input placeholder="Description" value={description} onChange={e => setDescription(e.target.value)} required />
                <button type="submit" className="btn btn-primary">Add Service</button>
            </form>
        </div>
    );
};

export default ManageServices;
