import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/axios';

const BookAppointment = () => {
    const [services, setServices] = useState([]);
    const [barbers, setBarbers] = useState([]); // We need a route to get barbers (users with role 'barber')
    const [selectedService, setSelectedService] = useState('');
    const [selectedBarber, setSelectedBarber] = useState('');
    const [date, setDate] = useState('');
    const navigate = useNavigate();
    const [error, setError] = useState('');

    useEffect(() => {
        fetchServices();
        fetchBarbers();
    }, []);

    const fetchServices = async () => {
        try {
            const res = await api.get('/services');
            setServices(res.data);
        } catch (error) {
            console.error(error);
        }
    };

    const fetchBarbers = async () => {
        try {
            // We need a route to get barbers. For now, let's assume we can filter users or add a specific route.
            // I didn't create a specific 'get all barbers' route, but I can add one or just use the admin user list if I was admin.
            // But regular users need to see barbers.
            // I'll add a quick route in server/routes/users.js to get barbers publically or just fetch all users and filter on client (bad practice but quick)
            // Better: Add /api/users/barbers route.
            const res = await api.get('/users/barbers');
            setBarbers(res.data);
        } catch (error) {
            console.error('Error fetching barbers:', error);
            // Fallback or mock if route doesn't exist yet
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await api.post('/appointments', {
                service: selectedService,
                barber: selectedBarber,
                date,
            });
            navigate('/dashboard');
        } catch (err) {
            setError(err.response?.data?.message || 'Booking failed');
        }
    };

    return (
        <div className="container" style={{ marginTop: '30px', maxWidth: '600px' }}>
            <h2>Book an Appointment</h2>
            {error && <p style={{ color: 'var(--error-color)' }}>{error}</p>}
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Select Service</label>
                    <select
                        value={selectedService}
                        onChange={(e) => setSelectedService(e.target.value)}
                        required
                    >
                        <option value="">-- Select Service --</option>
                        {services.map((service) => (
                            <option key={service.id} value={service.id}>
                                {service.name} (${service.price})
                            </option>
                        ))}
                    </select>
                </div>

                <div className="form-group">
                    <label>Select Barber</label>
                    <select
                        value={selectedBarber}
                        onChange={(e) => setSelectedBarber(e.target.value)}
                        required
                    >
                        <option value="">-- Select Barber --</option>
                        {barbers.map((barber) => (
                            <option key={barber.id} value={barber.id}>
                                {barber.name}
                            </option>
                        ))}
                    </select>
                </div>

                <div className="form-group">
                    <label>Date & Time</label>
                    <input
                        type="datetime-local"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        required
                    />
                </div>

                <button type="submit" className="btn btn-primary">
                    Confirm Booking
                </button>
            </form>
        </div>
    );
};

export default BookAppointment;
