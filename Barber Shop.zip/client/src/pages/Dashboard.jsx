import { useAuth } from '../context/AuthContext';
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/axios';
import ManageServices from '../components/ManageServices';
import ManageSchedule from '../components/ManageSchedule';

const Dashboard = () => {
    const { user } = useAuth();
    const [appointments, setAppointments] = useState([]);
    const [services, setServices] = useState([]);

    useEffect(() => {
        if (user) {
            fetchAppointments();
            if (user.role === 'admin') {
                fetchServices();
            }
        }
    }, [user]);

    const fetchAppointments = async () => {
        try {
            let endpoint = '/appointments/my';
            if (user.role === 'barber') endpoint = '/appointments/barber';

            const res = await api.get(endpoint);
            setAppointments(res.data);
        } catch (error) {
            console.error(error);
        }
    };

    const fetchServices = async () => {
        try {
            const res = await api.get('/services');
            setServices(res.data);
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <div className="container" style={{ marginTop: '30px' }}>
            <h1>Welcome, {user?.name}</h1>
            <p>Role: {user?.role}</p>

            <div style={{ marginTop: '30px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <h2>Your Appointments</h2>
                    {user.role === 'user' && (
                        <Link to="/book" className="btn btn-primary">Book New Appointment</Link>
                    )}
                </div>
                {appointments.length === 0 ? (
                    <p>No appointments found.</p>
                ) : (
                    <div style={{ display: 'grid', gap: '20px', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))' }}>
                        {appointments.map((appt) => (
                            <div key={appt.id} className="card">
                                <h3>{appt.service?.name || 'Service'}</h3>
                                <p>Date: {new Date(appt.date).toLocaleString()}</p>
                                <p>Status: {appt.status}</p>
                                {user.role === 'user' && <p>Barber: {appt.barber?.name}</p>}
                                {user.role === 'barber' && <p>Client: {appt.user?.name}</p>}
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {user?.role === 'admin' && (
                <div style={{ marginTop: '50px' }}>
                    <h2>Manage Services</h2>
                    <ul>
                        {services.map(service => (
                            <li key={service.id}>{service.name} - ${service.price}</li>
                        ))}
                    </ul>
                    <ManageServices services={services} onServiceAdded={(newService) => setServices([...services, newService])} />
                </div>
            )}

            {user?.role === 'barber' && (
                <div style={{ marginTop: '50px' }}>
                    <h2>Manage Schedule</h2>
                    <ManageSchedule />
                </div>
            )}
        </div>
    );
};

export default Dashboard;
