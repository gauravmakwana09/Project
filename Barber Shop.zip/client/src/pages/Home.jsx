import { Link } from 'react-router-dom';
import heroImage from '../assets/hero.png';

const Home = () => {
    return (
        <div className="home-container">
            <div className="hero-section" style={{ backgroundImage: `linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url(${heroImage})` }}>
                <div className="hero-content">
                    <h1 className="hero-title">Elevate Your Style</h1>
                    <p className="hero-subtitle">
                        Experience the art of grooming with our master barbers. <br />
                        Precision cuts, classic shaves, and a premium atmosphere.
                    </p>
                    <Link to="/login" className="btn btn-primary btn-lg">
                        Book Your Appointment
                    </Link>
                </div>
            </div>

            <div className="features-section container">
                <div className="feature-card">
                    <h3>Expert Barbers</h3>
                    <p>Our team consists of highly skilled professionals dedicated to perfection.</p>
                </div>
                <div className="feature-card">
                    <h3>Premium Products</h3>
                    <p>We use only the finest grooming products for your hair and beard.</p>
                </div>
                <div className="feature-card">
                    <h3>Relaxing Atmosphere</h3>
                    <p>Sit back, relax, and enjoy a complimentary beverage while we take care of you.</p>
                </div>
            </div>
        </div>
    );
};

export default Home;
